package br.venson.net.designpatterns.mediator;

public class Main {

    public static void main(String[] args) {
        Usuario ana = new Usuario("Ana");
        Usuario bruno = new Usuario("Bruno");
        Usuario carla = new Usuario("Carla");

        // Cada usuario precisa conhecer todos os outros, um a um.
        ana.adicionarContato(bruno);
        ana.adicionarContato(carla);
        bruno.adicionarContato(ana);
        bruno.adicionarContato(carla);
        carla.adicionarContato(ana);
        carla.adicionarContato(bruno);

        ana.enviar("Bom dia, pessoal!");

        // Tente responder: quantas ligacoes novas seriam criadas para incluir o
        // Diego na sala? E para remover a Carla de todas as listas de contatos?
    }
}
